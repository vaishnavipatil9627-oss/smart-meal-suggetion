const mongoose = require('mongoose');

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true },

    // food preferences
    dietPreference: { type: String, enum: ['veg', 'egg', 'nonveg'], default: 'veg' },
    allergies: { type: [String], default: [] },
    servings: { type: Number, default: 1, min: 1, max: 20 }, // people you cook for

    timezone: { type: String, default: 'Asia/Kolkata' },

    // reminder settings
    notify: {
      enabled: { type: Boolean, default: true },
      morningTime: { type: String, default: '07:30' }, // HH:mm
      eveningTime: { type: String, default: '18:30' },
    },
    lastSent: {
      morning: { type: String, default: '' }, // YYYY-MM-DD of last sent reminder
      evening: { type: String, default: '' },
    },

    // browser push subscriptions (one per browser/device)
    pushSubscriptions: { type: [mongoose.Schema.Types.Mixed], default: [] },
  },
  { timestamps: true }
);

module.exports = mongoose.model('User', userSchema);
