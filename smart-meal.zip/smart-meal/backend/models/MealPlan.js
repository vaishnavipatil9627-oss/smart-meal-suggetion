const mongoose = require('mongoose');

const mealPlanSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    date: { type: String, required: true }, // YYYY-MM-DD
    breakfast: { type: String, default: null }, // meal id from data/meals.js
    lunch: { type: String, default: null },
    dinner: { type: String, default: null },
  },
  { timestamps: true }
);

mealPlanSchema.index({ user: 1, date: 1 }, { unique: true });

module.exports = mongoose.model('MealPlan', mealPlanSchema);
