// Quick self-check of the suggestion + ingredient logic (no database needed): npm test
const assert = require('assert');
const { MEALS, suggestDay, swapMeal, candidatesFor, MEAL_BY_ID } = require('../services/suggest');
const { buildIngredientList } = require('../services/ingredients');
const { addDays, monthRange, todayIn, minutesNowIn, timeToMinutes } = require('../utils/dates');

const mk = (diet, allergies = []) => ({ _id: 'u1', dietPreference: diet, allergies });

// data sanity
const ids = MEALS.map((m) => m.id);
assert.strictEqual(new Set(ids).size, ids.length, 'meal ids must be unique');
['breakfast', 'lunch', 'dinner'].forEach((s) => assert(MEALS.filter((m) => m.slot === s).length >= 8, `enough ${s} meals`));

// veg user never gets egg / non-veg
for (let i = 0; i < 60; i++) {
  const day = suggestDay(mk('veg'), addDays('2026-10-01', i));
  for (const s of ['breakfast', 'lunch', 'dinner']) assert.strictEqual(MEAL_BY_ID[day[s]].diet, 'veg');
}

// egg user never gets non-veg
for (let i = 0; i < 60; i++) {
  const day = suggestDay(mk('egg'), addDays('2026-10-01', i));
  for (const s of ['breakfast', 'lunch', 'dinner']) assert.notStrictEqual(MEAL_BY_ID[day[s]].diet, 'nonveg');
}

// allergies are respected (peanut and dairy)
for (const allergy of ['peanut', 'dairy', 'egg', 'gluten']) {
  for (const s of ['breakfast', 'lunch', 'dinner']) {
    candidatesFor(s, mk('nonveg', [allergy])).forEach((m) => {
      const text = m.ingredients.map((i) => i.name.toLowerCase()).join('|');
      const words = { peanut: ['peanut'], dairy: ['milk', 'curd', 'paneer', 'ghee', 'butter', 'cream'], egg: ['egg'], gluten: ['wheat', 'rava', 'bread', 'pav', 'oats', 'bhajani'] }[allergy];
      words.forEach((w) => assert(!text.includes(w), `${m.name} contains ${w}`));
    });
    assert(candidatesFor(s, mk('nonveg', [allergy])).length > 0, `${allergy}: still has ${s} options`);
  }
}

// same user + date => same plan (deterministic)
assert.deepStrictEqual(suggestDay(mk('veg'), '2026-10-13'), suggestDay(mk('veg'), '2026-10-13'));

// avoids recent meals
const first = suggestDay(mk('veg'), '2026-10-13');
const next = suggestDay(mk('veg'), '2026-10-14', { breakfast: [first.breakfast], lunch: [first.lunch], dinner: [first.dinner] });
['breakfast', 'lunch', 'dinner'].forEach((s) => assert.notStrictEqual(next[s], first[s]));

// swap gives a different meal of the same slot
const sw = swapMeal(mk('veg'), 'lunch', first.lunch);
assert.notStrictEqual(sw, first.lunch);
assert.strictEqual(MEAL_BY_ID[sw].slot, 'lunch');

// ingredient aggregation: same ingredient is summed and scaled by servings
const list = buildIngredientList([{ date: '2026-10-13', breakfast: 'b01', lunch: 'l01', dinner: 'd01' }], 2);
const onion = list.find((i) => i.name === 'Onion');
assert(onion && onion.qty === 4, 'onion: 1 (poha) + 1 (dal rice) = 2 per person, x2 servings = 4');
assert(list.every((i) => i.category), 'every item has a category');

// date helpers
assert.strictEqual(addDays('2026-12-31', 1), '2027-01-01');
assert.deepStrictEqual(monthRange('2026-02'), { first: '2026-02-01', last: '2026-02-28' });
assert.strictEqual(todayIn('Asia/Kolkata', new Date('2026-10-13T20:00:00Z')), '2026-10-14'); // 01:30 IST next day
assert.strictEqual(minutesNowIn('Asia/Kolkata', new Date('2026-10-13T02:00:00Z')), 7 * 60 + 30);
assert.strictEqual(timeToMinutes('07:30'), 450);

console.log('All checks passed ✔');
