require('dotenv').config();
const path = require('path');
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

if (!process.env.JWT_SECRET) {
  console.error('Missing JWT_SECRET. Copy .env.example to .env and set it.');
  process.exit(1);
}

const { initPush } = require('./services/push');
const { startScheduler } = require('./services/notifier');

const app = express();
app.use(cors());
app.use(express.json());

// API
app.use('/api/auth', require('./routes/auth'));
app.use('/api/meals', require('./routes/meals'));
app.use('/api/ingredients', require('./routes/ingredients'));
app.use('/api/notifications', require('./routes/notifications'));
app.get('/api/health', (req, res) => res.json({ ok: true }));

// Frontend (served from ../frontend)
const FRONTEND = path.join(__dirname, '..', 'frontend');
app.use(express.static(FRONTEND));
app.get('/', (req, res) => res.sendFile(path.join(FRONTEND, 'index.html')));

// unknown API route -> JSON 404
app.use('/api', (req, res) => res.status(404).json({ message: 'Not found' }));

const PORT = process.env.PORT || 5000;
const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/smartmeal';

mongoose
  .connect(MONGO_URI)
  .then(() => {
    console.log('MongoDB connected');
    initPush();
    startScheduler();
    app.listen(PORT, () => console.log(`Smart Meal running -> http://localhost:${PORT}`));
  })
  .catch((err) => {
    console.error('MongoDB connection failed:', err.message);
    process.exit(1);
  });
