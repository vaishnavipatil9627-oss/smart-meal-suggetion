const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const Notification = require('../models/Notification');
const auth = require('../middleware/auth');
const { isValidTime } = require('../utils/dates');

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const DIETS = ['veg', 'egg', 'nonveg'];

const makeToken = (id) => jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: '7d' });

function parseAllergies(value) {
  const arr = Array.isArray(value) ? value : String(value || '').split(',');
  return [...new Set(arr.map((a) => String(a).trim().toLowerCase()).filter(Boolean))].slice(0, 20);
}

function publicUser(u) {
  return {
    id: u._id,
    name: u.name,
    email: u.email,
    dietPreference: u.dietPreference,
    allergies: u.allergies,
    servings: u.servings,
    timezone: u.timezone,
    notify: u.notify,
    pushDevices: (u.pushSubscriptions || []).length,
  };
}

// REGISTER
router.post('/register', async (req, res) => {
  try {
    const { name, email, password, dietPreference, allergies } = req.body;

    if (!name || !email || !password) return res.status(400).json({ message: 'Name, email and password are required' });
    if (!EMAIL_RE.test(email)) return res.status(400).json({ message: 'Please enter a valid email' });
    if (password.length < 6) return res.status(400).json({ message: 'Password must be at least 6 characters' });
    if (dietPreference && !DIETS.includes(dietPreference)) return res.status(400).json({ message: 'Invalid diet preference' });

    const exists = await User.findOne({ email: email.toLowerCase() });
    if (exists) return res.status(400).json({ message: 'This email is already registered' });

    const hashed = await bcrypt.hash(password, 10);
    const user = await User.create({
      name: name.trim(),
      email,
      password: hashed,
      dietPreference: dietPreference || 'veg',
      allergies: parseAllergies(allergies),
    });

    await Notification.create({
      user: user._id,
      type: 'welcome',
      title: 'Welcome to Smart Meal! 🎉',
      message: `Hi ${user.name.split(' ')[0]}, your daily meal suggestions are ready. You will get a morning and an evening reminder with your ingredients list.`,
    });

    res.status(201).json({ token: makeToken(user._id), user: publicUser(user) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

// LOGIN
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email: String(email || '').toLowerCase() });
    if (!user || !(await bcrypt.compare(password || '', user.password)))
      return res.status(400).json({ message: 'Wrong email or password' });

    res.json({ token: makeToken(user._id), user: publicUser(user) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

// CURRENT USER
router.get('/me', auth, async (req, res) => {
  const user = await User.findById(req.userId);
  if (!user) return res.status(401).json({ message: 'User not found' });
  res.json(publicUser(user));
});

// UPDATE PROFILE + SETTINGS
router.put('/me', auth, async (req, res) => {
  try {
    const { name, dietPreference, allergies, servings, notify } = req.body;
    const update = {};

    if (name !== undefined) {
      if (!String(name).trim()) return res.status(400).json({ message: 'Name cannot be empty' });
      update.name = String(name).trim();
    }
    if (dietPreference !== undefined) {
      if (!DIETS.includes(dietPreference)) return res.status(400).json({ message: 'Invalid diet preference' });
      update.dietPreference = dietPreference;
    }
    if (allergies !== undefined) update.allergies = parseAllergies(allergies);
    if (servings !== undefined) {
      const n = Number(servings);
      if (!Number.isInteger(n) || n < 1 || n > 20) return res.status(400).json({ message: 'Servings must be between 1 and 20' });
      update.servings = n;
    }
    if (notify) {
      if (notify.enabled !== undefined) update['notify.enabled'] = !!notify.enabled;
      for (const k of ['morningTime', 'eveningTime']) {
        if (notify[k] !== undefined) {
          if (!isValidTime(notify[k])) return res.status(400).json({ message: 'Time must be in HH:mm format' });
          update[`notify.${k}`] = notify[k];
        }
      }
    }

    const user = await User.findByIdAndUpdate(req.userId, { $set: update }, { new: true });
    res.json(publicUser(user));
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
