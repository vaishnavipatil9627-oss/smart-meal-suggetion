const router = require('express').Router();
const mongoose = require('mongoose');
const auth = require('../middleware/auth');
const User = require('../models/User');
const Notification = require('../models/Notification');
const { getPublicKey } = require('../services/push');
const { notify, sendMorning, sendEvening } = require('../services/notifier');

// public key needed by the browser to subscribe (no login needed)
router.get('/vapid-key', (req, res) => res.json({ key: getPublicKey() }));

router.use(auth);

// list notifications (latest 50) + unread count
router.get('/', async (req, res) => {
  const [items, unread] = await Promise.all([
    Notification.find({ user: req.userId }).sort({ createdAt: -1 }).limit(50),
    Notification.countDocuments({ user: req.userId, read: false }),
  ]);
  res.json({ unread, items });
});

// mark all as read
router.post('/read-all', async (req, res) => {
  await Notification.updateMany({ user: req.userId, read: false }, { read: true });
  res.json({ ok: true });
});

// mark one as read
router.patch('/:id/read', async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: 'Invalid id' });
  await Notification.updateOne({ _id: req.params.id, user: req.userId }, { read: true });
  res.json({ ok: true });
});

// delete one
router.delete('/:id', async (req, res) => {
  if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: 'Invalid id' });
  await Notification.deleteOne({ _id: req.params.id, user: req.userId });
  res.json({ ok: true });
});

// save this browser's push subscription
router.post('/subscribe', async (req, res) => {
  const sub = req.body;
  if (!sub || !sub.endpoint || !sub.keys) return res.status(400).json({ message: 'Invalid subscription' });
  // replace an older entry of the same browser, then add
  await User.updateOne({ _id: req.userId }, { $pull: { pushSubscriptions: { endpoint: sub.endpoint } } });
  await User.updateOne({ _id: req.userId }, { $push: { pushSubscriptions: sub } });
  res.json({ ok: true });
});

router.post('/unsubscribe', async (req, res) => {
  const { endpoint } = req.body;
  if (!endpoint) return res.status(400).json({ message: 'endpoint required' });
  await User.updateOne({ _id: req.userId }, { $pull: { pushSubscriptions: { endpoint } } });
  res.json({ ok: true });
});

// send a test notification right now: ?kind=test|morning|evening
router.post('/test', async (req, res) => {
  const user = await User.findById(req.userId);
  const kind = req.body.kind || 'test';
  if (kind === 'morning') await sendMorning(user);
  else if (kind === 'evening') await sendEvening(user);
  else
    await notify(user, {
      type: 'test',
      title: 'Test notification ✅',
      message: 'Great! Notifications are working on this device.',
    });
  res.json({ ok: true });
});

module.exports = router;
