const router = require('express').Router();
const auth = require('../middleware/auth');
const User = require('../models/User');
const MealPlan = require('../models/MealPlan');
const { SLOTS, expandPlan, totalCalories, swapMeal } = require('../services/suggest');
const { getOrCreatePlan } = require('../services/plans');
const { buildIngredientList } = require('../services/ingredients');
const { isValidDate, todayIn, addDays, dateRange, monthRange } = require('../utils/dates');

router.use(auth);

// attach the loaded user to the request
router.use(async (req, res, next) => {
  req.user = await User.findById(req.userId);
  if (!req.user) return res.status(401).json({ message: 'User not found' });
  next();
});

function dayResponse(user, plan) {
  const day = expandPlan(plan);
  return {
    ...day,
    totalCalories: totalCalories(day),
    ingredientCount: buildIngredientList([plan], user.servings).length,
  };
}

// TODAY
router.get('/today', async (req, res) => {
  const date = todayIn(req.user.timezone);
  const plan = await getOrCreatePlan(req.user, date);
  res.json(dayResponse(req.user, plan));
});

// ANY DAY
router.get('/day/:date', async (req, res) => {
  if (!isValidDate(req.params.date)) return res.status(400).json({ message: 'Invalid date' });
  const plan = await getOrCreatePlan(req.user, req.params.date);
  res.json(dayResponse(req.user, plan));
});

// SWAP one meal of a day for another suggestion
router.post('/day/:date/swap', async (req, res) => {
  const { date } = req.params;
  const { slot } = req.body;
  if (!isValidDate(date)) return res.status(400).json({ message: 'Invalid date' });
  if (!SLOTS.includes(slot)) return res.status(400).json({ message: 'slot must be breakfast, lunch or dinner' });

  const plan = await getOrCreatePlan(req.user, date);
  const neighbours = await MealPlan.find({ user: req.user._id, date: { $in: [addDays(date, -1), addDays(date, 1)] } });
  const avoid = neighbours.map((p) => p[slot]).filter(Boolean);

  plan[slot] = swapMeal(req.user, slot, plan[slot], avoid);
  await plan.save();
  res.json(dayResponse(req.user, plan));
});

// CALENDAR: all days of a month  (?month=YYYY-MM)
router.get('/calendar', async (req, res) => {
  const month = req.query.month || todayIn(req.user.timezone).slice(0, 7);
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(month)) return res.status(400).json({ message: 'month must be YYYY-MM' });

  const { first, last } = monthRange(month);
  const dates = dateRange(first, last);
  const existing = await MealPlan.find({ user: req.user._id, date: { $gte: first, $lte: last } });
  const byDate = Object.fromEntries(existing.map((p) => [p.date, p]));

  const days = [];
  for (const d of dates) {
    const plan = byDate[d] || (await getOrCreatePlan(req.user, d)); // create in date order so repeats are avoided
    days.push({ ...expandPlan(plan), totalCalories: totalCalories(expandPlan(plan)) });
  }
  res.json({ month, today: todayIn(req.user.timezone), days });
});

module.exports = router;
