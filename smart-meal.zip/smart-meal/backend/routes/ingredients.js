const router = require('express').Router();
const auth = require('../middleware/auth');
const User = require('../models/User');
const { getPlansForDates } = require('../services/plans');
const { buildIngredientList, formatQty } = require('../services/ingredients');
const { isValidDate, todayIn, addDays, dateRange } = require('../utils/dates');

router.use(auth);

// GET /api/ingredients?range=today|tomorrow|week   or   ?from=YYYY-MM-DD&to=YYYY-MM-DD
router.get('/', async (req, res) => {
  const user = await User.findById(req.userId);
  if (!user) return res.status(401).json({ message: 'User not found' });

  const today = todayIn(user.timezone);
  let from = today;
  let to = today;
  const { range, from: qf, to: qt } = req.query;

  if (qf && qt) {
    if (!isValidDate(qf) || !isValidDate(qt) || qf > qt) return res.status(400).json({ message: 'Invalid date range' });
    from = qf;
    to = qt;
  } else if (range === 'tomorrow') {
    from = to = addDays(today, 1);
  } else if (range === 'week') {
    to = addDays(today, 6);
  }

  const dates = dateRange(from, to);
  if (dates.length > 31) return res.status(400).json({ message: 'Range too long (max 31 days)' });

  const plans = await getPlansForDates(user, dates);
  const items = buildIngredientList(plans, user.servings).map((i) => ({ ...i, display: formatQty(i) }));
  res.json({ from, to, days: dates.length, servings: user.servings, count: items.length, items });
});

module.exports = router;
