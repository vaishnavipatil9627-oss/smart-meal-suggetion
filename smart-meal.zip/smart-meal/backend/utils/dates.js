// Date helpers. Dates are plain 'YYYY-MM-DD' strings so time zones never shift them.

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

function isValidDate(str) {
  if (!DATE_RE.test(str || '')) return false;
  const d = new Date(str + 'T00:00:00Z');
  return !isNaN(d) && d.toISOString().slice(0, 10) === str;
}

// today's date string in a given time zone
function todayIn(tz = 'Asia/Kolkata', now = new Date()) {
  return new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' }).format(now);
}

// current time as minutes since midnight in a given time zone
function minutesNowIn(tz = 'Asia/Kolkata', now = new Date()) {
  const parts = new Intl.DateTimeFormat('en-GB', { timeZone: tz, hour: '2-digit', minute: '2-digit', hourCycle: 'h23' })
    .formatToParts(now)
    .reduce((acc, p) => ((acc[p.type] = p.value), acc), {});
  return parseInt(parts.hour, 10) * 60 + parseInt(parts.minute, 10);
}

function timeToMinutes(hhmm) {
  const [h, m] = String(hhmm || '').split(':').map(Number);
  if (isNaN(h) || isNaN(m)) return null;
  return h * 60 + m;
}

function isValidTime(hhmm) {
  return /^([01]\d|2[0-3]):[0-5]\d$/.test(hhmm || '');
}

function addDays(dateStr, n) {
  const d = new Date(dateStr + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

// all dates from..to inclusive
function dateRange(from, to) {
  const out = [];
  for (let d = from; d <= to; d = addDays(d, 1)) out.push(d);
  return out;
}

function monthRange(ym) {
  // ym = 'YYYY-MM'
  const [y, m] = ym.split('-').map(Number);
  const first = `${y}-${String(m).padStart(2, '0')}-01`;
  const last = new Date(Date.UTC(y, m, 0)).toISOString().slice(0, 10);
  return { first, last };
}

module.exports = { isValidDate, todayIn, minutesNowIn, timeToMinutes, isValidTime, addDays, dateRange, monthRange };
