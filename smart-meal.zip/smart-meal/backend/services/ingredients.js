// Build a combined shopping / ingredients list from one or more daily plans.
const { SLOTS, MEAL_BY_ID } = require('./suggest');

const CATEGORY_RULES = [
  ['Vegetables & Fruits', ['onion', 'tomato', 'potato', 'chilli', 'coriander', 'curry leaves', 'lemon', 'ginger', 'garlic', 'spinach', 'peas', 'capsicum', 'cucumber', 'carrot', 'vegetable', 'banana', 'coconut', 'tamarind', 'kokum']],
  ['Dairy & Eggs', ['milk', 'curd', 'paneer', 'ghee', 'butter', 'cream', 'egg']],
  ['Meat & Fish', ['chicken', 'mutton', 'fish']],
  ['Grains, Flour & Bread', ['rice', 'poha', 'rava', 'wheat', 'flour', 'bread', 'pav', 'oats', 'sabudana', 'batter', 'bhajani', 'jowar', 'besan']],
  ['Pulses & Dry Fruits', ['dal', 'rajma', 'chickpea', 'moong', 'moth', 'peanut', 'almond']],
  ['Spices & Masala', ['masala', 'turmeric', 'cumin', 'mustard', 'pepper', 'spices', 'oil', 'pickle', 'chutney', 'honey', 'farsan']],
];

function categorize(name) {
  const n = name.toLowerCase();
  for (const [cat, words] of CATEGORY_RULES) if (words.some((w) => n.includes(w))) return cat;
  return 'Other';
}

function round(n) {
  return Math.round(n * 100) / 100;
}

// plans: array of {date, breakfast, lunch, dinner} (meal ids). servings multiplies quantities.
function buildIngredientList(plans, servings = 1) {
  const map = new Map();
  for (const plan of plans) {
    for (const slot of SLOTS) {
      const meal = MEAL_BY_ID[plan[slot]];
      if (!meal) continue;
      for (const ing of meal.ingredients) {
        const key = `${ing.name}|${ing.unit}`;
        if (!map.has(key)) map.set(key, { name: ing.name, unit: ing.unit, qty: 0, category: categorize(ing.name), usedIn: [] });
        const item = map.get(key);
        item.qty += ing.qty * servings;
        item.usedIn.push({ date: plan.date, slot, meal: meal.name });
      }
    }
  }
  const items = [...map.values()].map((i) => ({ ...i, qty: round(i.qty) }));
  items.sort((a, b) => a.category.localeCompare(b.category) || a.name.localeCompare(b.name));
  return items;
}

function formatQty(item) {
  const q = item.qty;
  if (item.unit === 'pcs') return `${q} pcs`;
  if (item.unit === 'g' && q >= 1000) return `${round(q / 1000)} kg`;
  if (item.unit === 'ml' && q >= 1000) return `${round(q / 1000)} L`;
  return `${q} ${item.unit}`;
}

module.exports = { buildIngredientList, formatQty, categorize };
