// Browser push notifications (Web Push + VAPID).
const fs = require('fs');
const path = require('path');
const webpush = require('web-push');
const User = require('../models/User');

const KEY_FILE = path.join(__dirname, '..', 'data', 'vapid.json');
let publicKey = '';

function initPush() {
  let pub = process.env.VAPID_PUBLIC_KEY;
  let priv = process.env.VAPID_PRIVATE_KEY;

  if (!pub || !priv) {
    if (fs.existsSync(KEY_FILE)) {
      ({ publicKey: pub, privateKey: priv } = JSON.parse(fs.readFileSync(KEY_FILE, 'utf8')));
    } else {
      const keys = webpush.generateVAPIDKeys();
      fs.writeFileSync(KEY_FILE, JSON.stringify(keys, null, 2));
      pub = keys.publicKey;
      priv = keys.privateKey;
      console.log('Generated new VAPID keys -> data/vapid.json');
    }
  }
  publicKey = pub;
  webpush.setVapidDetails(process.env.VAPID_SUBJECT || 'mailto:admin@smartmeal.local', pub, priv);
}

function getPublicKey() {
  return publicKey;
}

// send a push to every subscribed browser of the user; drops expired subscriptions
async function sendPushToUser(user, payload) {
  const subs = user.pushSubscriptions || [];
  if (!subs.length) return 0;

  const body = JSON.stringify(payload);
  const dead = [];
  let sent = 0;

  await Promise.all(
    subs.map(async (sub) => {
      try {
        await webpush.sendNotification(sub, body);
        sent++;
      } catch (err) {
        if (err.statusCode === 404 || err.statusCode === 410) dead.push(sub.endpoint);
        else console.error('Push error:', err.statusCode || err.message);
      }
    })
  );

  if (dead.length) {
    await User.updateOne({ _id: user._id }, { $pull: { pushSubscriptions: { endpoint: { $in: dead } } } });
  }
  return sent;
}

module.exports = { initPush, getPublicKey, sendPushToUser };
