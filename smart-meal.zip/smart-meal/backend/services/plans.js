// Load / create meal plans for a user.
const MealPlan = require('../models/MealPlan');
const { SLOTS, suggestDay } = require('./suggest');
const { addDays } = require('../utils/dates');

const AVOID_DAYS = 3; // don't repeat a meal used in the last 3 days

async function getOrCreatePlan(user, dateStr) {
  const existing = await MealPlan.findOne({ user: user._id, date: dateStr });
  if (existing) return existing;

  // meals used on the previous days (to avoid repeats)
  const prevDates = Array.from({ length: AVOID_DAYS }, (_, i) => addDays(dateStr, -(i + 1)));
  const prev = await MealPlan.find({ user: user._id, date: { $in: prevDates } });
  const recent = { breakfast: [], lunch: [], dinner: [] };
  prev.forEach((p) => SLOTS.forEach((s) => p[s] && recent[s].push(p[s])));

  const meals = suggestDay(user, dateStr, recent);

  // upsert so two simultaneous requests can't create duplicates
  return MealPlan.findOneAndUpdate(
    { user: user._id, date: dateStr },
    { $setOnInsert: { user: user._id, date: dateStr, ...meals } },
    { new: true, upsert: true }
  );
}

async function getPlansForDates(user, dates) {
  const plans = [];
  for (const d of dates) plans.push(await getOrCreatePlan(user, d));
  return plans;
}

module.exports = { getOrCreatePlan, getPlansForDates };
