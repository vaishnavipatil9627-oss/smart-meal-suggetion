// Smart suggestion engine: picks breakfast / lunch / dinner for a day.
//  - respects diet preference (veg / egg / nonveg)
//  - removes meals containing the user's allergens
//  - avoids repeating the same meal within the last few days
//  - deterministic per user+date (same day always gives same plan), random for "swap"
const MEALS = require('../data/meals');

const SLOTS = ['breakfast', 'lunch', 'dinner'];
const MEAL_BY_ID = Object.fromEntries(MEALS.map((m) => [m.id, m]));

// allergy word -> ingredient keywords it should block
const ALLERGY_ALIASES = {
  dairy: ['milk', 'curd', 'paneer', 'ghee', 'butter', 'cream'],
  milk: ['milk', 'curd', 'paneer', 'ghee', 'butter', 'cream'],
  nuts: ['peanut', 'almond', 'cashew'],
  peanut: ['peanut'],
  gluten: ['wheat', 'rava', 'bread', 'pav', 'oats', 'bhajani'],
  egg: ['egg'],
  fish: ['fish'],
  soy: ['soy'],
};

function allergenKeywords(allergies = []) {
  const set = new Set();
  for (const raw of allergies) {
    const a = String(raw).trim().toLowerCase();
    if (!a) continue;
    (ALLERGY_ALIASES[a] || [a.replace(/s$/, '')]).forEach((k) => set.add(k));
  }
  return [...set];
}

function dietAllows(userDiet, mealDiet) {
  if (userDiet === 'veg') return mealDiet === 'veg';
  if (userDiet === 'egg') return mealDiet === 'veg' || mealDiet === 'egg';
  return true; // nonveg / any
}

function candidatesFor(slot, user) {
  const blocked = allergenKeywords(user.allergies);
  return MEALS.filter(
    (m) =>
      m.slot === slot &&
      dietAllows(user.dietPreference, m.diet) &&
      !m.ingredients.some((i) => blocked.some((k) => i.name.toLowerCase().includes(k)))
  );
}

// small seeded PRNG so a given day always gives the same suggestion
function hashString(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// recentIds: { breakfast:[ids], lunch:[ids], dinner:[ids] } meals used in the last few days
function suggestDay(user, dateStr, recentIds = {}) {
  const result = {};
  for (const slot of SLOTS) {
    const all = candidatesFor(slot, user);
    if (!all.length) { result[slot] = null; continue; }
    const recent = new Set(recentIds[slot] || []);
    let pool = all.filter((m) => !recent.has(m.id));
    if (!pool.length) pool = all;
    const rand = mulberry32(hashString(`${user._id}|${dateStr}|${slot}`));
    result[slot] = pool[Math.floor(rand() * pool.length)].id;
  }
  return result;
}

// pick a different meal for one slot ("swap" button)
function swapMeal(user, slot, currentId, avoidIds = []) {
  const all = candidatesFor(slot, user);
  let pool = all.filter((m) => m.id !== currentId && !avoidIds.includes(m.id));
  if (!pool.length) pool = all.filter((m) => m.id !== currentId);
  if (!pool.length) return currentId;
  return pool[Math.floor(Math.random() * pool.length)].id;
}

function expandPlan(plan) {
  return {
    date: plan.date,
    breakfast: MEAL_BY_ID[plan.breakfast] || null,
    lunch: MEAL_BY_ID[plan.lunch] || null,
    dinner: MEAL_BY_ID[plan.dinner] || null,
  };
}

function totalCalories(expanded) {
  return SLOTS.reduce((sum, s) => sum + (expanded[s] ? expanded[s].calories : 0), 0);
}

module.exports = { SLOTS, MEALS, MEAL_BY_ID, suggestDay, swapMeal, expandPlan, totalCalories, candidatesFor, allergenKeywords };
