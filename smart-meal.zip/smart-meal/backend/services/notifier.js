// Creates in-app notifications + browser push, and runs the morning / evening reminder scheduler.
const cron = require('node-cron');
const User = require('../models/User');
const Notification = require('../models/Notification');
const { sendPushToUser } = require('./push');
const { getOrCreatePlan } = require('./plans');
const { buildIngredientList, formatQty } = require('./ingredients');
const { MEAL_BY_ID } = require('./suggest');
const { todayIn, addDays, minutesNowIn, timeToMinutes } = require('../utils/dates');

const CATCH_UP_MINUTES = 90; // if the server was off at the exact minute, still send within 90 min

async function notify(user, { type, title, message, url = '/home.html' }) {
  const doc = await Notification.create({ user: user._id, type, title, message, url });
  await sendPushToUser(user, { title, body: message, url, tag: type, id: String(doc._id) });
  return doc;
}

function ingredientSummary(items, max = 8) {
  const names = items.map((i) => `${i.name.replace(/\s*\(.*\)/, '')} (${formatQty(i)})`);
  const shown = names.slice(0, max).join(', ');
  return names.length > max ? `${shown} +${names.length - max} more` : shown;
}

async function sendMorning(user) {
  const today = todayIn(user.timezone);
  const plan = await getOrCreatePlan(user, today);
  const items = buildIngredientList([plan], user.servings);
  const nm = (id) => (MEAL_BY_ID[id] ? MEAL_BY_ID[id].name : '-');
  return notify(user, {
    type: 'morning',
    title: `Good morning ${user.name.split(' ')[0]}! Today's meals`,
    message:
      `Breakfast: ${nm(plan.breakfast)} | Lunch: ${nm(plan.lunch)} | Dinner: ${nm(plan.dinner)}. ` +
      `Keep ready: ${ingredientSummary(items)}`,
    url: '/ingredients.html?range=today',
  });
}

async function sendEvening(user) {
  const tomorrow = addDays(todayIn(user.timezone), 1);
  const plan = await getOrCreatePlan(user, tomorrow);
  const items = buildIngredientList([plan], user.servings);
  const nm = (id) => (MEAL_BY_ID[id] ? MEAL_BY_ID[id].name : '-');
  return notify(user, {
    type: 'evening',
    title: `Tomorrow's plan is ready`,
    message:
      `Breakfast: ${nm(plan.breakfast)} | Lunch: ${nm(plan.lunch)} | Dinner: ${nm(plan.dinner)}. ` +
      `Buy / arrange: ${ingredientSummary(items)}`,
    url: '/ingredients.html?range=tomorrow',
  });
}

// runs every minute: sends reminders whose time has come and that were not sent today
async function checkReminders(now = new Date()) {
  const users = await User.find({ 'notify.enabled': true });
  for (const user of users) {
    try {
      const tz = user.timezone || 'Asia/Kolkata';
      const today = todayIn(tz, now);
      const nowMin = minutesNowIn(tz, now);

      for (const [kind, sender] of [['morning', sendMorning], ['evening', sendEvening]]) {
        const at = timeToMinutes(user.notify[kind + 'Time']);
        if (at === null) continue;
        const due = nowMin >= at && nowMin < at + CATCH_UP_MINUTES;
        if (due && user.lastSent[kind] !== today) {
          // mark first, so a slow send can never fire twice
          await User.updateOne({ _id: user._id }, { $set: { [`lastSent.${kind}`]: today } });
          await sender(user);
          console.log(`[reminder] ${kind} sent to ${user.email}`);
        }
      }
    } catch (err) {
      console.error('[reminder] failed for', user.email, err.message);
    }
  }
}

function startScheduler() {
  cron.schedule('* * * * *', () => checkReminders().catch((e) => console.error(e)));
  console.log('Reminder scheduler started (checks every minute)');
}

module.exports = { notify, sendMorning, sendEvening, checkReminders, startScheduler };
