// Shared helpers for all pages
const API = location.protocol === 'file:' ? 'http://localhost:5000/api' : '/api';

/* ---------------- auth storage ---------------- */
const Auth = {
  token: () => localStorage.getItem('token'),
  user: () => { try { return JSON.parse(localStorage.getItem('user')); } catch { return null; } },
  save(token, user) { localStorage.setItem('token', token); localStorage.setItem('user', JSON.stringify(user)); },
  clear() { localStorage.removeItem('token'); localStorage.removeItem('user'); },
  require() { if (!Auth.token()) { location.href = 'login.html'; return false; } return true; },
  logout() { Auth.clear(); location.href = 'login.html'; },
};

/* ---------------- api helper ---------------- */
async function api(path, { method = 'GET', body } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (Auth.token()) headers.Authorization = 'Bearer ' + Auth.token();

  let res;
  try {
    res = await fetch(API + path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  } catch {
    throw new Error('Cannot reach server. Is the backend running?');
  }
  let data = {};
  try { data = await res.json(); } catch { /* no body */ }

  if (res.status === 401 && Auth.token()) { Auth.clear(); location.href = 'login.html'; throw new Error(data.message || 'Please login'); }
  if (!res.ok) throw new Error(data.message || 'Something went wrong');
  return data;
}

/* ---------------- small utils ---------------- */
function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function toast(msg, ms = 2600) {
  const t = document.createElement('div');
  t.className = 'toast';
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), ms);
}
function timeAgo(iso) {
  const s = Math.floor((Date.now() - new Date(iso)) / 1000);
  if (s < 60) return 'just now';
  if (s < 3600) return Math.floor(s / 60) + ' min ago';
  if (s < 86400) return Math.floor(s / 3600) + ' h ago';
  return new Date(iso).toLocaleDateString();
}
function prettyDate(dateStr) {
  return new Date(dateStr + 'T00:00:00').toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long' });
}
const SLOT_LABEL = { breakfast: '🌅 Breakfast', lunch: '☀️ Lunch', dinner: '🌙 Dinner' };
const DIET_LABEL = { veg: 'Veg', egg: 'Egg', nonveg: 'Non-veg' };

/* ---------------- meal card ---------------- */
function mealCardHtml(slot, meal, date, { swap = true } = {}) {
  if (!meal) {
    return `<div class="card meal-card"><span class="slot-tag slot-${slot}">${SLOT_LABEL[slot]}</span>
      <p style="color:var(--muted)">No meal matches your diet / allergy settings. Please check Settings.</p></div>`;
  }
  return `
  <div class="card meal-card" data-slot="${slot}">
    <span class="slot-tag slot-${slot}">${SLOT_LABEL[slot]}</span>
    <h3>${esc(meal.name)}</h3>
    <div class="meal-meta">
      <span><i class="diet-dot diet-${meal.diet}"></i>${DIET_LABEL[meal.diet]}</span>
      <span>🔥 ${meal.calories} kcal</span>
      <span>⏱ ${meal.time} min</span>
    </div>
    <div class="chips">${meal.ingredients.map((i) => `<span class="chip">${esc(i.name.replace(/\s*\(.*\)/, ''))}</span>`).join('')}</div>
    <div class="how"><b>How to make:</b> ${esc(meal.steps)}</div>
    ${swap ? `<div class="card-actions"><button class="btn light small" onclick="swapMeal('${date}','${slot}',this)">🔄 Suggest another</button></div>` : ''}
  </div>`;
}

/* ---------------- header / nav / notification bell ---------------- */
function renderHeader(active) {
  const user = Auth.user() || {};
  const links = [
    ['home', 'home.html', '🏠 Home'],
    ['ingredients', 'ingredients.html', '🛒 Ingredients'],
    ['calendar', 'calendar.html', '📅 Calendar'],
    ['settings', 'settings.html', '⚙️ Settings'],
  ];
  document.getElementById('app-header').innerHTML = `
  <div class="topbar"><div class="topbar-in">
    <div class="brand">🥗 Smart Meal</div>
    <nav class="nav">${links.map(([k, h, t]) => `<a href="${h}" class="${k === active ? 'active' : ''}">${t}</a>`).join('')}</nav>
    <div class="top-right">
      <button class="bell" id="bell" title="Notifications">🔔<span class="badge hidden" id="badge">0</span></button>
      <span class="user-name">${esc(user.name || '')}</span>
      <button class="btn outline small" onclick="Auth.logout()">Logout</button>
    </div>
  </div>
  <div class="notif-panel hidden" id="notif-panel"></div></div>`;

  document.getElementById('bell').onclick = (e) => { e.stopPropagation(); toggleNotifPanel(); };
  document.addEventListener('click', (e) => {
    const p = document.getElementById('notif-panel');
    if (p && !p.contains(e.target)) p.classList.add('hidden');
  });
  refreshNotifications();
  setInterval(refreshNotifications, 30000);
  registerServiceWorker();
}

let lastNotifs = [];
async function refreshNotifications() {
  try {
    const { unread, items } = await api('/notifications');
    lastNotifs = items;
    const b = document.getElementById('badge');
    if (b) { b.textContent = unread > 99 ? '99+' : unread; b.classList.toggle('hidden', unread === 0); }
    const p = document.getElementById('notif-panel');
    if (p && !p.classList.contains('hidden')) drawNotifPanel();
  } catch { /* ignore polling errors */ }
}

function toggleNotifPanel() {
  const p = document.getElementById('notif-panel');
  p.classList.toggle('hidden');
  if (!p.classList.contains('hidden')) drawNotifPanel();
}

function drawNotifPanel() {
  const p = document.getElementById('notif-panel');
  p.innerHTML = `
    <div class="notif-head"><span>Notifications</span>
      <button class="btn light small" onclick="markAllRead(event)">Mark all read</button></div>
    ${lastNotifs.length
      ? lastNotifs.map((n) => `
        <div class="notif-item ${n.read ? '' : 'unread'}" onclick="openNotif('${n._id}','${esc(n.url)}')">
          <b>${esc(n.title)}</b><p>${esc(n.message)}</p><time>${timeAgo(n.createdAt)}</time>
        </div>`).join('')
      : '<div class="notif-empty">No notifications yet</div>'}`;
}

async function openNotif(id, url) {
  try { await api(`/notifications/${id}/read`, { method: 'PATCH' }); } catch {}
  location.href = url || 'home.html';
}
async function markAllRead(e) {
  e.stopPropagation();
  await api('/notifications/read-all', { method: 'POST' });
  refreshNotifications();
}

/* ---------------- push notifications ---------------- */
function pushSupported() {
  return 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;
}
async function registerServiceWorker() {
  if (!('serviceWorker' in navigator) || location.protocol === 'file:') return null;
  try { return await navigator.serviceWorker.register('/sw.js'); } catch { return null; }
}
function urlBase64ToUint8Array(b64) {
  const pad = '='.repeat((4 - (b64.length % 4)) % 4);
  const raw = atob((b64 + pad).replace(/-/g, '+').replace(/_/g, '/'));
  return Uint8Array.from([...raw].map((c) => c.charCodeAt(0)));
}
async function getPushSubscription() {
  if (!pushSupported()) return null;
  const reg = await navigator.serviceWorker.ready;
  return reg.pushManager.getSubscription();
}
async function enablePush() {
  if (!pushSupported()) throw new Error('This browser does not support push notifications');
  const perm = await Notification.requestPermission();
  if (perm !== 'granted') throw new Error('Notification permission was blocked. Allow it in browser site settings.');

  await registerServiceWorker();
  const reg = await navigator.serviceWorker.ready;
  const { key } = await api('/notifications/vapid-key');
  let sub = await reg.pushManager.getSubscription();
  if (!sub) sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: urlBase64ToUint8Array(key) });
  await api('/notifications/subscribe', { method: 'POST', body: sub.toJSON() });
}
async function disablePush() {
  const sub = await getPushSubscription();
  if (!sub) return;
  await api('/notifications/unsubscribe', { method: 'POST', body: { endpoint: sub.endpoint } });
  await sub.unsubscribe();
}

/* ---------------- swap a meal (used on home + calendar) ---------------- */
async function swapMeal(date, slot, btn) {
  btn.disabled = true;
  try {
    await api(`/meals/day/${date}/swap`, { method: 'POST', body: { slot } });
    if (typeof onMealsChanged === 'function') await onMealsChanged(date);
    toast('New suggestion added ✔');
  } catch (e) {
    toast(e.message);
    btn.disabled = false;
  }
}
