// Service worker: shows push notifications even when the site is closed
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));

self.addEventListener('push', (event) => {
  let data = {};
  try { data = event.data ? event.data.json() : {}; } catch { data = { title: 'Smart Meal', body: event.data && event.data.text() }; }

  event.waitUntil(
    self.registration.showNotification(data.title || 'Smart Meal', {
      body: data.body || '',
      tag: data.tag || 'smart-meal',
      data: { url: data.url || '/home.html' },
      icon: '/icon.svg',
      badge: '/icon.svg',
    })
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const url = (event.notification.data && event.notification.data.url) || '/home.html';
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
      for (const c of list) {
        if ('focus' in c) { c.navigate(url); return c.focus(); }
      }
      return self.clients.openWindow(url);
    })
  );
});
