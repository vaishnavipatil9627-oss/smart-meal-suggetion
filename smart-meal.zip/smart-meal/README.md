# 🥗 Smart Meal Suggestion

Daily breakfast / lunch / dinner suggestions, ingredients list, meal calendar, and morning + evening reminder notifications.

**Stack:** HTML + CSS + JavaScript (frontend) · Node.js + Express (backend) · MongoDB (database) · Web Push (notifications)

## Features

| Page | What it does |
|------|--------------|
| Register / Login | Account with password hashing (bcrypt) and JWT login. Choose Veg / Egg / Non-veg and allergies at signup |
| Home | Today's 3 meals with calories, time and how-to. "Suggest another" button swaps a meal. Tomorrow preview |
| Ingredients | Combined shopping list for Today / Tomorrow / Next 7 days, grouped by category, with tick boxes, progress bar, copy and print |
| Calendar | Month view of every day's meals, tap a day for details, swap meals, month navigation |
| Settings | Diet, allergies, number of people (scales quantities), morning/evening reminder times, enable browser notifications, test buttons |
| Notifications | 🔔 bell with unread count + real browser push notifications (works even when the site is closed) |

### How the smart suggestion works
- Only meals that match your diet (veg / egg / non-veg) are used
- Meals containing your allergens are removed (e.g. `dairy` blocks milk, curd, paneer, ghee, butter, cream)
- The same meal is not repeated within the last 3 days
- Same user + same date always gives the same plan; "Suggest another" gives a different one

### Reminders
- **Morning** (default 07:30): today's meals + ingredients to keep ready
- **Evening** (default 18:30): tomorrow's meals + ingredients to buy
- A scheduler checks every minute (user's time zone, default Asia/Kolkata). If the server was off at the exact minute, the reminder is still sent within 90 minutes
- Each reminder is saved in the bell list and also pushed to the browser

## Run it

1. Install **Node.js 18+** and **MongoDB Community** (or use a free MongoDB Atlas link).
2. In a terminal:

```bash
cd backend
npm install
cp .env.example .env      # Windows: copy .env.example .env
# edit .env: set JWT_SECRET to any long random text, and MONGO_URI if you use Atlas
npm start
```

3. Open **http://localhost:5000** in Chrome/Edge. The backend also serves the frontend, so nothing else is needed.

## Test notifications

1. Register and open **Settings**
2. Click **Enable on this device** and press *Allow*
3. Click **Preview morning reminder** / **Preview evening reminder**. You will see it in the 🔔 bell and as a browser notification
4. To test the real schedule, set the morning time to 2 minutes from now and click *Save reminder settings*

> Browser push works on `http://localhost` and on `https://` sites. On a deployed site you must use HTTPS (Render, Railway, etc. give this automatically).
> Push keys (VAPID) are generated automatically on first start in `backend/data/vapid.json`. For deployment, set `VAPID_PUBLIC_KEY` and `VAPID_PRIVATE_KEY` in the environment instead (`npm run keys` prints a new pair).

## Folder structure

```
smart-meal/
  backend/
    server.js                 app start, serves frontend + API
    data/meals.js             39 meals with ingredients, calories, steps  (add your own here!)
    models/                   User, MealPlan, Notification
    routes/                   auth, meals, ingredients, notifications
    services/                 suggest (engine), plans, ingredients, push, notifier (scheduler)
    middleware/auth.js        JWT check
    test/suggest.test.js      npm test  (checks diet, allergy, repeat and ingredient logic)
  frontend/
    index.html login.html register.html home.html
    ingredients.html calendar.html settings.html
    css/style.css  js/app.js  sw.js (push service worker)
```

## API summary

| Method | Endpoint | Purpose |
|--------|----------|---------|
| POST | /api/auth/register, /api/auth/login | create account / login |
| GET, PUT | /api/auth/me | profile + settings |
| GET | /api/meals/today | today's plan |
| GET | /api/meals/day/:date | any day (YYYY-MM-DD) |
| POST | /api/meals/day/:date/swap | `{ "slot": "lunch" }` suggest another meal |
| GET | /api/meals/calendar?month=YYYY-MM | whole month |
| GET | /api/ingredients?range=today\|tomorrow\|week | combined ingredients |
| GET | /api/notifications | list + unread count |
| POST | /api/notifications/subscribe, /unsubscribe, /test, /read-all | push + test |

## Add more meals

Open `backend/data/meals.js` and copy any line, for example:

```js
m('b14', 'Besan Chilla', 'breakfast', 'veg', 220, 15,
  [['Besan (gram flour)', 60, 'g'], ['Onion', 1, 'pcs']],
  'Mix besan with water and onion, cook on tawa.'),
```

`slot` = breakfast / lunch / dinner, `diet` = veg / egg / nonveg. Quantities are per 1 person.
